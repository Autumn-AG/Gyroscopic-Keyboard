## Contributing guidelines

All guidelines for contributing to the Seeed_Arduino_IMU10DOF repository can be found at [`How to contribute guideline`](https://github.com/Seeed-Studio/Seeed_Arduino_IMU10DOF/wiki/How_to_contribute).
